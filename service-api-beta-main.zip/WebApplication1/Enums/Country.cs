﻿namespace WebApplication1.Enums
{
    public enum Country
    {
        United_States,
        United_Kingdom,
        Canada,
        Australia,
        Germany,
        Mexico,
        Spain,
        Cuba
    }
}
